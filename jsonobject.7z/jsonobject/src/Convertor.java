import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Convertor {

	public static void main(String[] args) throws IOException {
		
		File file = new File("Car1131.txt");
		File outF = new File("F:/output.txt");
		
        FileWriter fw = new FileWriter(outF.getAbsoluteFile());

		String sCurrentLine;
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		
		BufferedWriter bWriter = new BufferedWriter(fw);	
		
	bWriter.write("hello world");
			
			try {
				String tempJson = "";
				while ((sCurrentLine = br.readLine()) != null) {
					String[] values = sCurrentLine.split("\t");
					
					tempJson+=("[{");
					tempJson+=("\"id\":"+"\""+values[0]+"\"");
					tempJson+=(",\"seq_i\":"+"\""+values[1]+"\"");
					tempJson+=(",\"cost_s\":"+"\""+values[2]+"\"");
					tempJson+=(",\"maint_s\":"+"\""+values[3]+"\"");
					tempJson+=(",\"doors_s\":"+"\""+values[4]+"\"");
					tempJson+=(",\"persons_s\":"+"\""+values[5]+"\"");
					tempJson+=(",\"bootspace_s\":"+"\""+values[6]+"\"");
					tempJson+=(",\"safety_s\":"+"\""+values[7]+"\"");
					tempJson+=("}]");
					
				      
			        System.out.println(tempJson);
			        bWriter.write(tempJson);
			        
					tempJson="";		
					
					// file.write(",\"title\":"+"\""+Array2[1]+"\"");	
					
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				
		
	}
	
}

